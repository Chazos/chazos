<?php

$plugin_info = array(
    'name' => 'Chazol',
    'version' => '1.0',
    'author' => 'Takunda Madechangu',
    'plugin_url' => 'http://www.azol.com.au',
    'author_url' => 'http://www.azol.com.au',
    'description' => 'Plugin to allow the Media Manager to add files from the webservers filesystem.',
    'installed' => true,
    'plugin_options' => [
        'settings' => 'http://www.meow.com',

    ]
);



